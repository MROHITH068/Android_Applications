package com.example.project1;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btn1;
    private TextView txtview;
    private Button btn2;
    private String PhoneNumber="";
    private boolean validNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    btn1 = (Button) findViewById(R.id.button1);
    btn2 = (Button) findViewById(R.id.button2);
    txtview = (TextView) findViewById(R.id.textView);
    btn1.setOnClickListener((View v)-> {
        Intent intent = new Intent(MainActivity.this,secondActivity.class);
        startActivityForResult(intent,2);
    });
    btn2.setOnClickListener((View v) ->{
        Intent intent2 = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+PhoneNumber));
        if(PhoneNumber.equals("")){
            Toast.makeText(MainActivity.this, "Please Enter a Number", Toast.LENGTH_LONG).show();
        }
        else if(validNumber == false){
            Toast.makeText(MainActivity.this, "Incorrect Number: " + PhoneNumber, Toast.LENGTH_LONG).show();
        }
        else{
            startActivity(intent2);
        }

    });
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("phn_no",PhoneNumber);
        outState.putBoolean("valid_status",validNumber);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        PhoneNumber = savedInstanceState.getString("phn_no","");
        validNumber = savedInstanceState.getBoolean("valid_status");
//        Toast.makeText(MainActivity.this,PhoneNumber,Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK){
            PhoneNumber = data.getStringExtra("phoneNumber");
            validNumber = true;
//            Toast.makeText(MainActivity.this,PhoneNumber,Toast.LENGTH_LONG).show();
        }
        else if(requestCode == 2 && resultCode == RESULT_CANCELED){
            PhoneNumber = data.getStringExtra("phoneNumber");
            validNumber = false;
        }
    }
}