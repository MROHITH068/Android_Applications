package com.example.project1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Pattern;

import java.util.regex.Matcher;

public class secondActivity extends AppCompatActivity {
    EditText editText;
    TextView txtview;
    String pattern1 ="^\\(\\d{3}\\)\\s?\\d{3}\\-\\d{4}$";
    String pattern2 ="^\\d{10}$";
    Matcher m1,m2;
    private String phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        txtview = (TextView) findViewById(R.id.textView2);
        editText = (EditText) findViewById(R.id.editTextPhone);
        if(savedInstanceState!=null){
            phone = savedInstanceState.getString("phone");
            editText.setText(phone);
        }

        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                phone = editText.getText().toString().trim();
                if (actionId == EditorInfo.IME_ACTION_DONE){
                    Pattern p1 = Pattern.compile(pattern1);
                    Pattern p2 = Pattern.compile(pattern2);
                    m1 = p1.matcher(phone);
                    m2 = p2.matcher(phone);
//                    if(!phone.isEmpty())
//                    {
//                        m1 = p1.matcher(phone);
//                        m2 = p2.matcher(phone);
//                    }
//                    else
//                    {
//                        Toast.makeText(secondActivity.this,"Enter valid number",Toast.LENGTH_LONG).show();
//                    }
                    Intent i = new Intent();
                    i.putExtra("phoneNumber",phone);
                    setResult(m1.find() || m2.find()?RESULT_OK:RESULT_CANCELED,i);
//                    if (m1.find() || m2.find()){
//                        setResult(i==null?RESULT_CANCELED:RESULT_OK,i);
//                    }
//                    else{
//                        Toast.makeText(secondActivity.this,"Enter valid number",Toast.LENGTH_LONG).show();
//                        setResult(RESULT_CANCELED,i);
//                    }
                    finish();
                    return true;
                }
                return false;
            }
        });
//        editText.setOnEditorActionListener(new View.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(View v, int keyCode, KeyEvent event) {
//                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER){
//                    Pattern p1 = Pattern.compile(pattern1);
//                    Pattern p2 = Pattern.compile(pattern2);
//                    phone = editText.getText().toString().trim();
//                    if(!phone.isEmpty())
//                    {
//                        m1 = p1.matcher(phone);
//                        m2 = p2.matcher(phone);
//                    }
//                    else
//                    {
//                        Toast.makeText(secondActivity.this,"Enter valid number",Toast.LENGTH_LONG).show();
//                    }
//                    if (m1.find() || m2.find()){
//                        Intent i = new Intent();
//                        i.putExtra("phoneNumber",phone);
//                        setResult(i==null?RESULT_CANCELED:RESULT_OK,i);
//                    }
//                    else{
//                        Toast.makeText(secondActivity.this,"Enter valid number",Toast.LENGTH_LONG).show();
//                        setResult(RESULT_CANCELED);
//                    }
//                    finish();
//                    return true;
//                }
//                return false;
//            }
//        });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("phone",editText.getText().toString().trim());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        phone = savedInstanceState.getString("phone","");
//        Toast.makeText(secondActivity.this,phone,Toast.LENGTH_LONG).show();
        editText.setText(phone);
    }
}