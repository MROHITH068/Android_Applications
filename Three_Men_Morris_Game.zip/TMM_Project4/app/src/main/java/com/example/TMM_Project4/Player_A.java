package com.example.TMM_Project4;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.util.Random;

public class Player_A implements Runnable {


    private int number_of_Pieces = 0;
    private Positions_Info[] pieces = null;
    public static Handler player_A_Handler;

    //run method of Player A thread
    public void run() {
        Looper.prepare();

        player_A_Handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch(msg.what) {
                    case 0:
                        Move();
                        break;
                    default: break;
                }
            }
        };

        GameBoard.handler_time_counter++;
        Looper.loop();
    }


    //makes a Move
    private void Move() {
        if(number_of_Pieces < 3) {
            if(pieces == null)
                pieces = new Positions_Info[3];
            add_new_Piece();
            return;
        }

        int pieceNumber = getRandomPiece();
        Positions_Info randomPoint = getRandomPoint();
        GameBoard.movePiece(pieces[pieceNumber], randomPoint);
    }

  //adds new piece on Board
    private void add_new_Piece() {
        pieces[number_of_Pieces] = getRandomPoint();
        GameBoard.movePiece(new Positions_Info(-1,-1,1), pieces[number_of_Pieces]);
        number_of_Pieces++;
    }

    //   returns a random piece
    private int getRandomPiece() {
        return new Random().nextInt(3);
    }

    // returns a random position
    private Positions_Info getRandomPoint() {
        int posX = new Random().nextInt(3);
        int posY = new Random().nextInt(3);

        while(!isFree(posX, posY)) {
            posX = new Random().nextInt(3);
            posY = new Random().nextInt(3);
        }
        return new Positions_Info(posX, posY, 1);
    }


    //Function: check if position is free
    private boolean isFree(int posX, int posY) {
        return GameBoard.getGameBoard()[posX][posY] == 0;
    }

    // quits looper and clear message queue

    public static void quitLooper() {
        player_A_Handler.removeCallbacksAndMessages(null);
        player_A_Handler.getLooper().quit();
    }
}
