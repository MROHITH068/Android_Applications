package com.example.TMM_Project4;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.util.Random;

public class Player_B implements Runnable {

    //instance variables
    private int number_of_Pieces = 0;
    private Positions_Info[] pieces = null;
    public static Handler player_B_Handler;

    //keep track of rows
    int[][] SelfBoard;

    //run method
    public void run() {
        Looper.prepare();
        player_B_Handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch(msg.what) {
                    case 0:
                        updateSelfBoard(new Positions_Info(msg.arg1, msg.arg2, 1), (Positions_Info)msg.obj);
                        Move();
                        break;
                    default: break;
                }
            }
        };

        initiateSelfBoard();
        GameBoard.handler_time_counter++;
        Looper.loop();
    }

  //Initializes the selfBoard
    private void initiateSelfBoard() {
        SelfBoard = new int[3][3];
        for(int i = 0; i < 3; i++)
            for(int j = 0; j < 3;j++)
                SelfBoard[i][j] = 0;
    }


//make a Move
    private void Move() {
        if(number_of_Pieces < 3) {
            if(pieces == null)
                pieces = new Positions_Info[3];
            addPiece();
            return;
        }

        Positions_Info analysisData = SelfBoardAnalyze();

        int pieceNumber = findBestPieceToMove(analysisData);

        Positions_Info newPosition = findBestOpenSpot(analysisData);

        updateSelfBoard(pieces[pieceNumber], newPosition);

        GameBoard.movePiece(pieces[pieceNumber], newPosition);
    }


    // place a piece at random location
    private void addPiece() {
        pieces[number_of_Pieces] = getRandomPoint();
        GameBoard.movePiece(new Positions_Info(-1,-1,2), pieces[number_of_Pieces]);
        updateSelfBoard(new Positions_Info(-1,-1,2), pieces[number_of_Pieces]);
        number_of_Pieces++;
    }

    //Update the SelfBoard.
    private void updateSelfBoard(Positions_Info previousPosition, Positions_Info newPosition) {
        if(newPosition == null)
            return;
        int oldX = previousPosition.getPosX();
        int oldY = previousPosition.getPosY();
        int newX = newPosition.getPosX();
        int newY = newPosition.getPosY();
        if(oldX != -1)
            SelfBoard[oldX][oldY] = 0;
        if(newPosition.getPlayerId() == 2)
            SelfBoard[newX][newY] = 1;
        else
            SelfBoard[newX][newY] = -1;
    }

    //Function that returns the random point for placing a new coin
    private Positions_Info getRandomPoint() {
        int posX = new Random().nextInt(3);
        int posY = new Random().nextInt(3);
        while(!isFree(posX, posY)) {
            posX = new Random().nextInt(3);
            posY = new Random().nextInt(3);
        }
        return new Positions_Info(posX, posY, 2);
    }



    private boolean isFree(int posX, int posY) {
        return GameBoard.getGameBoard()[posX][posY] == 0;
    }

    //   Function: Loops which quits looper and empties message queue

    public static void quitLooper() {
        player_B_Handler.removeCallbacksAndMessages(null);
        player_B_Handler.getLooper().quit();
    }

    //Function that find best piece to move among the pieces which are placed on the board
    private int findBestPieceToMove(Positions_Info verifyBoard) {
        if(number_of_Pieces < 3)
            return -1;
        int rowOrCol = verifyBoard.getPlayerId();
        int locationNum = verifyBoard.getPosX();
        for(int i = 0; i < 3; i++) {
            if (rowOrCol == 3 && pieces[i].getPosX() != locationNum)
                return i;
            else if (rowOrCol == 4 && pieces[i].getPosY() != locationNum)
                return i;
        }

        return -1;

    }

    //finds best spot to place a new coin
    private Positions_Info findBestOpenSpot(Positions_Info verifyBoard) {
        int rowOrCol = verifyBoard.getPlayerId();
        int locationNum = verifyBoard.getPosX();
        for(int i = 0; i < 3; i++) {
            if(rowOrCol == 3 && isFree(locationNum, i))
                return new Positions_Info(locationNum, i, 2);
            else if(rowOrCol == 4 && isFree(i, locationNum))
                return new Positions_Info(i, locationNum, 2);
        }
        return getRandomPoint();
    }

    //  Function that analyze the self board and generate analyzed data and returns them.

    private Positions_Info SelfBoardAnalyze() {
        Positions_Info maxPoint = new Positions_Info(-1, -1, -1);
        for(int i = 0; i < 3; i++) {
            int Horizontal_count = 0;
            int Vertical_count = 0;
            for (int j = 0; j < 3; j++) {
                Horizontal_count += SelfBoard[i][j];
                Vertical_count += SelfBoard[j][i];
            }
            if(maxPoint.getPosY() < Horizontal_count) {
                maxPoint.setPosX(i);
                maxPoint.setPosY(Horizontal_count);
                maxPoint.setPlayerId(3);
                if(Horizontal_count == 2)
                    return maxPoint;
            }
            else if(maxPoint.getPosY() < Vertical_count) {
                maxPoint.setPosX(i);
                maxPoint.setPosY(Vertical_count);
                maxPoint.setPlayerId(4);
                if(Vertical_count == 2)
                    return maxPoint;
            }
        }
        return maxPoint;
    }
}
