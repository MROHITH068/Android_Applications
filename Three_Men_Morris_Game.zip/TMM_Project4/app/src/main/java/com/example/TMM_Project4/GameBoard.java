package com.example.TMM_Project4;

import android.os.Handler;
import android.os.Message;

public class GameBoard {

    //instance variables
    private static int[][] gameBoard;
    public static int handler_time_counter;
    private static Handler mainHandler;

    //constructor
    public GameBoard(Handler mainHandler) {

        handler_time_counter = 0;

        initiateGameBoard();

        this.mainHandler = mainHandler;
    }

  //initiates the GameBoard
    private void initiateGameBoard() {
        gameBoard = new int[3][3];
        for(int i = 0; i < 3; i++)
            for(int j = 0; j < 3; j++)
                gameBoard[i][j] = 0;
    }

  // function that moves the piece
    public synchronized static void movePiece(Positions_Info PreviousPosition, Positions_Info newPosition) {
        pauseThread();

        int oldX = PreviousPosition.getPosX();
        int oldY = PreviousPosition.getPosY();

        int newX = newPosition.getPosX();
        int newY = newPosition.getPosY();

        if(oldX != -1)
            gameBoard[oldX][oldY] = 0;

        gameBoard[newX][newY] = newPosition.getPlayerId();

        PreviousPosition.setPosX(newX);
        PreviousPosition.setPosY(newY);

        Message msg = mainHandler.obtainMessage(0, oldX, oldY, PreviousPosition);
        mainHandler.sendMessage(msg);
    }

    // returns the gameBoard
    public synchronized static int[][] getGameBoard() {
        return gameBoard;
    }

    //pauses the Thread
    public static void pauseThread() {
        try{
            Thread.sleep(1000);
        }catch(InterruptedException i) {

        }
    }
}
