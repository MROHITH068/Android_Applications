package com.example.TMM_Project4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;



import java.util.Random;

public class MainActivity extends AppCompatActivity {


    // stores multiple text views
    private static TextView[][] gameBoard;
    private static Thread player_A_Thread;
    private static Thread player_B_Thread;

    //creates handler for UI or main thread
    private  Handler mainHandler = new Handler() {
        @Override
        public void handleMessage( Message msg) {
            switch(msg.what) {
                case 0:
                    UI_update((Positions_Info)msg.obj, msg.arg1, msg.arg2);
                    break;
                default: break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        player_A_Thread = null;
        player_B_Thread = null;
        initiateGameBoard();
    }

    //Initialize the textViews
    private void initiateGameBoard() {
        gameBoard = new TextView[3][3];
        assigntextviews();
    }


    //   Function which updates the UI with new positions and old positions as parameters
    private void UI_update(Positions_Info newPosition, int prev_X, int prev_Y) {
        //check if newly placed
        if(prev_X != -1)
            gameBoard[prev_X][prev_Y].setBackgroundColor(getResources().getColor(R.color.teal_200));

        //get positions
        int newX = newPosition.getPosX();
        int newY = newPosition.getPosY();

        //place piece
        if(newPosition.getPlayerId() == 1)

            gameBoard[newX][newY].setBackground(getResources().getDrawable(R.drawable.black_circle));
        else
            gameBoard[newX][newY].setBackground(getResources().getDrawable(R.drawable.white_circle));


        //check for winning conditions
        int id = checkForWin();

        //if winning condition reached then call victory reached
        if(id != -1) {
            hasWon(id, this);
            return;
        }

        //get next move
        nextMove(newPosition, prev_X, prev_Y);

    }

    // initiate next Move by calling respective Thread Handlers
    private static void nextMove(Positions_Info newPosition, int Prev_X, int Prev_Y) {
        if(newPosition.getPlayerId() == 2)
            Player_A.player_A_Handler.sendMessage(Player_A.player_A_Handler.obtainMessage(0, Prev_X, Prev_Y, newPosition));
        else
            Player_B.player_B_Handler.sendMessage(Player_B.player_B_Handler.obtainMessage(0, Prev_X, Prev_Y, newPosition));
    }

   //Assigning TextViews to GameBoard
    private void assigntextviews() {
        gameBoard[0][2] = findViewById(R.id.textview_02);
        gameBoard[0][1] = findViewById(R.id.textview_01);
        gameBoard[0][0] = findViewById(R.id.textview_00);
        gameBoard[1][0] = findViewById(R.id.textview_10);
        gameBoard[1][1] = findViewById(R.id.textview_11);
        gameBoard[1][2] = findViewById(R.id.textview_12);
        gameBoard[2][0] = findViewById(R.id.textview_20);
        gameBoard[2][1] = findViewById(R.id.textview_21);
        gameBoard[2][2] = findViewById(R.id.textview_22);
    }


    public void onStartGameClicked(View view) {
        if(player_A_Thread != null)
            stopThreads();
        new GameBoard(mainHandler);
        initiateThreads();
        cleanGameBoard();
        startGame();
    }

    //Clears the GameBoard
    private void cleanGameBoard() {
        for(int i = 0; i < 3; i++)
            for(int j = 0; j < 3; j++)
                gameBoard[i][j].setBackgroundColor(getResources().getColor(R.color.teal_200));
    }

   // Creates new Threads
    private void initiateThreads() {
        player_A_Thread = new Thread(new Player_A());
        player_B_Thread = new Thread(new Player_B());
    }

    //starts the game
    private void startGame() {
        GameBoard.handler_time_counter = 0;
        player_A_Thread.start();
        player_B_Thread.start();
        int startingThread = new Random().nextInt(2);
        while(GameBoard.handler_time_counter < 2);
        if(startingThread == 0)
            Player_A.player_A_Handler.sendMessage(Player_A.player_A_Handler.obtainMessage(0));
        else
            Player_B.player_B_Handler.sendMessage(Player_B.player_B_Handler.obtainMessage(0));
    }

   //checks for winning condition
    private int checkForWin() {
        int[][] gameState = GameBoard.getGameBoard();
        for(int i = 0; i < 3; i++) {
            int Horizontal_val = gameState[i][0];
            int Vertical_val = gameState[0][i];
            int countHoriz = 0;
            int countVert = 0;
            for (int j = 0; j < 3; j++) {
                if (gameState[i][j] == Horizontal_val)
                    countHoriz++;
                if (gameState[j][i] == Vertical_val)
                    countVert++;
            }
            if (Horizontal_val != 0 && countHoriz == 3) {
                return Horizontal_val;
            }
            if (Vertical_val != 0 && countVert == 3) {
                return Vertical_val;
            }
        }
        return -1;

    }

    // Stops the thread
    private void stopThreads() {

        Player_A.player_A_Handler.post(new Runnable() {
            @Override
            public void run() {
                Player_A.quitLooper();
            }
        });
        Player_B.player_B_Handler.post(new Runnable() {
            @Override
            public void run() {
                Player_B.quitLooper();
            }
        });

        while(player_A_Thread.isAlive());
        while(player_B_Thread.isAlive());

        player_A_Thread = null;
        player_B_Thread = null;


        mainHandler.removeCallbacksAndMessages(null);
    }

    //Toastifies the winner
    private void hasWon(int PlayerId, Context activity) {
        stopThreads();
        if(PlayerId == 1)
            Toast.makeText(activity, "Black Wins!!", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(activity, "White Wins!!", Toast.LENGTH_LONG).show();
    }

}