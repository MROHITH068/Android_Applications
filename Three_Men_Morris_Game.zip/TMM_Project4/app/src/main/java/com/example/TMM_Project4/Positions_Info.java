package com.example.TMM_Project4;

public class Positions_Info {

    private int position_X;
    private int position_Y;
    private int playerId;

    //constructor
    public Positions_Info(int x, int y, int playerId) {
        position_X = x;
        position_Y = y;
        this.playerId = playerId;
    }

    // return x position
    public int getPosX() {
        return position_X;
    }

    //sets the position of the x for the object
    public void setPosX(int posX) {
        position_X = posX;
    }

    //returns the y position
    public int getPosY() {
        return position_Y;
    }

    //sets the the position of y for the object
    public void setPosY(int posY) {
        position_Y = posY;
    }

    //returns the PlayerId
    public int getPlayerId() {
        return playerId;
    }

    //sets the PlayerId for the object
    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }
}
