package course.examples.UI.GridLayout;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class DealersList extends AppCompatActivity {
    ListView listView;
    private int pos;
    // Dealers Names
    String[][] Dealer_Name = {{"McGrath City Mazda","The Autobarn Mazda of Evanston"},{"Wilkins Mazda","Napleton's Oak Lawn Mazda"},{"Kia of Lincolnwood","Berwyn Kia"},{"Evergreen Kia","Willowbrook Kia"},{"Honda of Downtown Chicago","McGrath City Honda"},{"Tesla","Tesla"},{"Toyota of Lincoln Park","Victory Toyota of Midtown"},{"Toyota On Western","Chicago Northside Toyota"}};
    // Dealers Addresses
    String[][] Dealer_Address = {{"6722 W Grand Ave, Chicago, IL 60707","1015 Chicago Ave, Evanston,Chicago, IL 60202"},{"740 N York St, Elmhurst, Chciago, IL 60126","6750 W 95th St, Oak Lawn, Chicago, IL 60453"},{"6750 Lincoln Ave, Lincolnwood, Chicago, IL 60712","7050 Ogden Ave, Berwyn, IL 60402"},{"9205 S Western Ave, Chicago, IL 60643","7335 Kingery Hwy, Willowbrook, IL 60527"},{"1111 N Clark St #2, Chicago, IL 60610","6720 W Grand Ave, Chicago, IL 60707"},{"1053 W Grand Ave, Chicago, IL 60642","901 N Rush St, Chicago, IL 60611"},{"1561 N Fremont St, Chicago, IL 60642","2700 N Cicero Ave, Chicago, IL 60639"},{"6042 N Western Ave, Chicago, IL 60659","6941 S Western Ave, Chicago, IL 60636"}};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dealers_list);
        // Listview is assigned to listView object
        listView = findViewById(R.id.listview2);

        Intent i = getIntent();
        // Getting and Storing the position value in pos variable with help of intent object.
        pos = i.getIntExtra("pos",0);
        // Intializing and calling the CustomAdapter  with the parameters
        CustomAdapter customAdapter = new CustomAdapter(this,R.layout.list_row,Dealer_Name[pos],Dealer_Address[pos]);
        // Attaching the adapter to the list view
        listView.setAdapter(customAdapter);
    }
}