package course.examples.UI.GridLayout;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Arrays;

public class ImageViewActivity extends Activity {
    // An ArrayList storing the Image labels which are in drawable folder.
    ArrayList<Integer> mcars = new ArrayList<>(
            Arrays.asList(R.drawable.mazdacx5, R.drawable.mazdacx9,
                    R.drawable.kiaseltos, R.drawable.kiacarnival, R.drawable.hondacrv,
                    R.drawable.teslamodelx, R.drawable.toyotacamry, R.drawable.toyotacorolla));

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // Get the Intent used to start this Activity
        Intent intent = getIntent();

        // Example of programmatic layout definition
        // Make a new ImageView
        ImageView imageView = new ImageView(getApplicationContext());

        // Get the ID of the image to display from the intent
        //   and set it as the image for this ImageView
        imageView.setImageResource(mcars.get(intent.getIntExtra("URL", 0)));

        // Define the content of this activity programmatically
        setContentView(imageView);
        // Defining a new intent to open website with ACTION_VIEW as action
        Intent i = new Intent(Intent.ACTION_VIEW);

        imageView.setOnClickListener((View.OnClickListener) v ->{
            // Defining the respective website URL as data when the image is clicked
            i.setData(Uri.parse(getApplicationContext().getResources().getStringArray(R.array.car_URLS)[intent.getIntExtra("URL",0)]));

            startActivity(i);
        });
    }




}