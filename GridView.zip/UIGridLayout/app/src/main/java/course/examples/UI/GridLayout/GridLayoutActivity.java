package course.examples.UI.GridLayout;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Arrays;

//This application uses some deprecated methods.
//See UIViewPager for a more modern version of this application

public class GridLayoutActivity extends Activity {

    protected static final String EXTRA_RES_ID = "POS";

    // An ArrayList storing the Thumbnail Image labels which are in drawable folder.
    private ArrayList<Integer> mThumbIdscars = new ArrayList<>(
            Arrays.asList(R.drawable.mazdacx5_thumbnail, R.drawable.mazdacx9_thumbnail,
                    R.drawable.kiaseltos_thumbnail, R.drawable.kiacarnival_thumbnail, R.drawable.hondacrv_thumbnail,
                    R.drawable.teslamodelx_thumbnail, R.drawable.toyotacamry_thumbnail, R.drawable.toyotacorolla_2_thumbnail));

    // Array that shows the car model names
    private String[] car_name = {"Mazda CX-5","Mazda CX-9","Kia SELTOS", "Kia CARNIVAL-MPV", "Honda CR-V", "Tesla MODELX","Toyota CAMRY", "Toyota COROLLA"};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Retrieve GridView declare in layout file
        GridView gridview = findViewById(R.id.gridview);

        // Create a new ImageAdapter and set it as the Adapter for this GridView
        gridview.setAdapter(new ImageAdapter(this, R.layout.grid_image_view ,mThumbIdscars,car_name));



        // Set an setOnItemClickListener on the GridView
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {

                //Create an Intent to start the ImageViewActivity
                Intent intent = new Intent(GridLayoutActivity.this,ImageViewActivity.class);
                // Add the ID of the thumbnail to display as an Intent Extra
                intent.putExtra(EXTRA_RES_ID, (int) id);
                intent.putExtra("URL",position);
                // Start the ImageViewActivity
                startActivity(intent);
            }

        });
        registerForContextMenu(gridview);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        //Inflating the contextmenu view
        getMenuInflater().inflate(R.menu.context_menu, menu);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        //Extra menu information provided to onCreateContextMenu when context menu added to the Adapter
        //and the information is stored in the info variable
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        // Used switch case to redirect to the activity with respective clicked cell information
        switch (item.getItemId()) {
            case R.id.view_car:
                // Creating an Explicit intent and calling activity ImageViewActivity to display the large size image
                Intent view_car_intent = new Intent(GridLayoutActivity.this,ImageViewActivity.class);
                // Sending the id and position of the clicked image as intent extras
                view_car_intent.putExtra(EXTRA_RES_ID,(int) info.id);
                view_car_intent.putExtra("URL",info.position);
                startActivity(view_car_intent);
                return true;
            case R.id.go_to_site:
                // Creating an Implicit intent to direct the user to the car manfacturer URL
                Intent go_to_site_intent = new Intent(Intent.ACTION_VIEW, Uri.parse(GridLayoutActivity.this.getResources().getStringArray(R.array.car_URLS)[info.position]));
                startActivity(go_to_site_intent);
                return true;
            case R.id.car_dealers:
                // Creating an Explicit intent and calling DealerList activity to display the list of dealers
                Intent car_dealers_intent = new Intent(GridLayoutActivity.this,DealersList.class);
                car_dealers_intent.putExtra("pos",info.position);
                startActivity(car_dealers_intent);
                return true;
                default:
                    return false;
        }
    }
}