package course.examples.UI.GridLayout;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ImageAdapter extends BaseAdapter {
    private static final int PADDING = 8;
    private static final int WIDTH = 320;
    private static final int HEIGHT = 430;
    private Context mContext;          // This will have to be passed to the ImageView
    private List<Integer> mThumbIds;   // Adapter must store AdapterView's items
    private int mResource;
    private String[] car_names;
    // Save the list of image IDs and the context
    public ImageAdapter(Context c,int resource, List<Integer> ids, String[] car_name) {
        mContext = c;
        this.mResource = resource;
        this.mThumbIds = ids;
        this.car_names = car_name;
    }

    // Now the methods inherited from abstract superclass BaseAdapter

    // Return the number of items in the Adapter
    @Override
    public int getCount() {
        return mThumbIds.size();
    }

    // Return the data item at position
    @Override
    public Object getItem(int position) {
        return mThumbIds.get(position);
    }

    // Will get called to provide the ID that
    // is passed to OnItemClickListener.onItemClick()
    @Override
    public long getItemId(int position) {
        return mThumbIds.get(position);
    }

    // Return an ImageView for each item referenced by the Adapter
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource,parent,false);

        ImageView imageView = convertView.findViewById(R.id.image_view);
        TextView textView = convertView.findViewById(R.id.carname);
        // if convertView's not recycled, create + initialize some attributes
//        if (imageView == null) {
//            imageView = new ImageView(mContext);
//            imageView.setLayoutParams(new GridView.LayoutParams(WIDTH, HEIGHT));
//            imageView.setPadding(PADDING, PADDING, PADDING, PADDING);
//            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
//        }

        // Put data (actual image reference) in imageView + return it
        imageView.setImageResource(mThumbIds.get(position));
        textView.setText(car_names[position]);

        return convertView;
    }
}
