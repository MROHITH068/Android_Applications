package course.examples.UI.GridLayout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    private Context mcontext;
    private String[] mdealer_name;
    private String[] mdealer_address;
    private int mResource;

    public CustomAdapter(Context context, int resource, String[] dealer_name, String[] dealer_address) {
         // Gets the DealerList.java context, list_row.xml as resource and dealers names and address as arrays and assigned to local variables
        this.mcontext = context;
        this.mResource = resource;
        this.mdealer_name = dealer_name;
        this.mdealer_address = dealer_address;
    }

    @Override
    public int getCount() {
        return mdealer_name.length;// returning the total length of the mdealer_name array
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Using LayoutInflater to inflate the list_row view on activity_dealers_list.xml file
        LayoutInflater layoutInflater = LayoutInflater.from(mcontext);
        convertView = layoutInflater.inflate(mResource,parent,false);
        //Calling the text views in list_row.xml file with the convertView Object
        TextView dlr_name = convertView.findViewById(R.id.dealer_name);
        TextView dlr_add = convertView.findViewById(R.id.dealer_address);
        //Setting the text for the text views in list_row.xml file
        dlr_name.setText(mdealer_name[position]);
        dlr_add.setText(mdealer_address[position]);
        // retruning the view object
        return convertView;
    }
}
