package edu.uic.cs478.project5.funcenter;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Base64;

import java.io.ByteArrayOutputStream;

public class FunCenterService extends Service {
    public FunCenterService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return binder;
    }

    MediaPlayer player;

    private final AIDLFunCenterInterface.Stub binder = new AIDLFunCenterInterface.Stub() {
        @Override
        public String getImageById(int imageId) throws RemoteException {
            int[] imageList = {
                    R.drawable.shape_of_you,
                    R.drawable.see_you_again,
                    R.drawable.pasoori
            };

            Drawable d = getResources().getDrawable(imageList[imageId]);
            Bitmap bitmap = ((BitmapDrawable)d).getBitmap();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();

            String imageString = Base64.encodeToString(byteArray, Base64.DEFAULT);

            return imageString;
        }

        @Override
        public void selectAndPlayMusicById(int songId) throws RemoteException {
            int[] musicList = {
                    R.raw.shape_of_you,
                    R.raw.see_you_again,
                    R.raw.pasoori
            };

            if (player != null) {
                if (player.isPlaying())
                    player.reset();
            }
            player = MediaPlayer.create(getApplicationContext(), musicList[songId]);
            player.start();
        }

        @Override
        public void playPauseMusic() throws RemoteException {
            if(player != null) {
                if (!player.isPlaying())
                    player.start();
                else
                    player.pause();
            }
        }

        @Override
        public void stopPlayingMusic() throws RemoteException {
            if(player != null)
                player.stop();
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        player.stop();
        player.release();
    }
}