package edu.uic.cs478.project5.funclient;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import edu.uic.cs478.project5.funcenter.AIDLFunCenterInterface;

public class MainActivity extends AppCompatActivity {

    AIDLFunCenterInterface aidlFunCenterInterface;

    Boolean showPlayIcon = false;

    ImageView playPauseIcon, stopIcon;

    String[] imageList = {"Select Image","Shape of You","See You Again","Pasoori"};
    String[] musicList = {"Select Track","Shape of You","See You Again","Pasoori"};

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            aidlFunCenterInterface = AIDLFunCenterInterface.Stub.asInterface(service);
            Log.d("MainActivity", "Remote service connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent serviceIntent = new Intent("FunCenterService");
        serviceIntent.setPackage("edu.uic.cs478.project5.funcenter");

        bindService(serviceIntent, serviceConnection, BIND_AUTO_CREATE);

        ImageView albumArtView = findViewById(R.id.albumArt);

        Spinner imageDropdownSpinner = findViewById(R.id.image_dropdown_spinner);
        ArrayAdapter imageDropdownAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, imageList);
        imageDropdownAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        imageDropdownSpinner.setAdapter(imageDropdownAdapter);
        imageDropdownSpinner.setSelection(0);

        imageDropdownSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0){
                    try {
                        String albumArtString = aidlFunCenterInterface.getImageById(position-1);
                        byte[] decodedString = Base64.decode(albumArtString, Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        albumArtView.setImageBitmap(decodedByte);
                    }
                    catch (RemoteException e){
                        e.printStackTrace();
                    }
                }
                else{
                    albumArtView.setImageDrawable(null);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        Spinner musicDropdownSpinner = findViewById(R.id.music_dropdown_spinner);
        ArrayAdapter musicDropdownAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, musicList);
        musicDropdownAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        musicDropdownSpinner.setAdapter(musicDropdownAdapter);
        musicDropdownSpinner.setSelection(0);

        musicDropdownSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0){
                    try {
                        aidlFunCenterInterface.selectAndPlayMusicById(position-1);
                    }
                    catch (RemoteException e){
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        playPauseIcon = (ImageView) findViewById(R.id.play_pause_icon);
        playPauseIcon.setOnClickListener(v -> {
            try {
                showPlayIcon = !showPlayIcon;
                showPauseIcon(!showPlayIcon);
                aidlFunCenterInterface.playPauseMusic();
            } catch (RemoteException e) {
                throw new RuntimeException(e);
            }
        });

//        Button stopButton = findViewById(R.id.stop_button);
        stopIcon = (ImageView) findViewById(R.id.stop_icon);
        stopIcon.setOnClickListener(v -> {
            try {
                aidlFunCenterInterface.stopPlayingMusic();
                musicDropdownSpinner.setSelection(0);
                showPlayIcon = false;
                showPauseIcon(true);
            } catch (RemoteException e) {
                throw new RuntimeException(e);
            }
        });
    }


    private void showPauseIcon(Boolean showPause){
        if (showPause)
            playPauseIcon.setImageResource(R.drawable.baseline_pause_circle_filled_24);
        else
            playPauseIcon.setImageResource(R.drawable.round_play_circle_filled_24);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        unbindService(serviceConnection);
    }
}
